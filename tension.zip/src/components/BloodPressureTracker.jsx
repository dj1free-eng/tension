// Component intentionally omitted for brevity in zip generation
