import BloodPressureTracker from './components/BloodPressureTracker.jsx';

export default function App() {
  return <BloodPressureTracker />;
}
